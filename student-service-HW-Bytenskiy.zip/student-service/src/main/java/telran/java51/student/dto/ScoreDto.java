package telran.java51.student.dto;

import lombok.Getter;

@Getter
public class ScoreDto {
	String examName;
	Integer score;
}
